import { IController } from './IController';
import * as express from 'express';
import { ValidationOptions, ValidationResult as JoiValidationResult } from 'joi';
import { PromiseResolver } from '../util/PromiseResolver';
export declare enum LogLevels {
    LOG = "LOG",
    INFO = "INFO",
    WARN = "WARN",
    ERROR = "ERROR"
}
export declare abstract class AbstractController extends PromiseResolver implements IController {
    protected processRequest(req: express.Request, res: express.Response): Promise<any>;
    protected getSegmentName(): string;
    protected validate(req: express.Request): JoiValidationResult<object>;
    protected getSchema(): object;
    protected getOptions(): ValidationOptions;
    protected next(req: express.Request, res: express.Response, next: (e: any) => {}, result: any): void;
    protected log(level: LogLevels, message: string, data?: Object, request?: express.Request, error?: Error): void;
    register(): Function;
}
