"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWSXRay = require("aws-xray-sdk");
const joi_1 = require("joi");
const ServiceError_1 = require("../error/ServiceError");
const UuidUtils_1 = require("../util/UuidUtils");
const PromiseResolver_1 = require("../util/PromiseResolver");
var LogLevels;
(function (LogLevels) {
    LogLevels["LOG"] = "LOG";
    LogLevels["INFO"] = "INFO";
    LogLevels["WARN"] = "WARN";
    LogLevels["ERROR"] = "ERROR";
})(LogLevels = exports.LogLevels || (exports.LogLevels = {}));
class AbstractController extends PromiseResolver_1.PromiseResolver {
    processRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            // log request recieved
            this.log(LogLevels.INFO, 'Request recieved', null, req);
            return new Promise((resolve, reject) => {
                try {
                    // first validate the incoming request.
                    const vResult = this.validate(req);
                    if (vResult.error !== null) {
                        this.log(LogLevels.ERROR, vResult.error.message, null, req, vResult.error);
                        return this.resolvePromise(null, resolve, reject, new Error(vResult.error.message), null);
                    }
                    // stub for override
                    // in your sub classes you should supply value for result and error
                    this.resolvePromise(null, resolve, reject, null, null);
                }
                catch (e) {
                    // log error response
                    this.log(LogLevels.ERROR, e.message, null, req, e);
                    return this.resolvePromise(null, resolve, reject, e, null);
                }
            });
        });
    }
    // stub for override
    getSegmentName() {
        return 'AbstractController';
    }
    // validate the payload
    validate(req) {
        const schema = this.getSchema();
        const options = this.getOptions();
        return joi_1.validate(req.body, schema, options);
    }
    getSchema() {
        return {};
    }
    getOptions() {
        return {
            allowUnknown: true
        };
    }
    // some controllers act as middleware and need to call next while others usually send a response
    // this is an override point for middleware
    next(req, res, next, result) {
        res.json(result);
    }
    log(level, message, data = null, request = null, error = null) {
        console.log({
            logLevel: level,
            message: message,
            data: data,
            request: (request) ? {
                id: request['id'] || null,
                protocol: request.protocol || null,
                method: request.method || null,
                headers: request.headers || null,
                body: request.body || null,
                query: request.query || null,
                params: request.params || null,
                host: request.hostname || null,
                path: request.path || null,
                isXhr: request.xhr || null,
            } : null,
            error: error,
        });
    }
    /*
     The register function wraps our async route handlers in a function so they can be used as express middleware
     Good article here: https://medium.com/@Abazhenov/using-async-await-in-express-with-node-8-b8af872c0016
     It also wraps the processRequest invocation in an XRay subsegment.
     Article here: https://docs.aws.amazon.com/xray/latest/devguide/xray-sdk-nodejs-subsegments.html
     Full XRay docs for nodeJS are here: https://docs.aws.amazon.com/xray-sdk-for-nodejs/latest/reference/index.html
     */
    register() {
        return (req, res, next) => {
            // populate request id if it doesn't exist
            req['id'] = (!req.hasOwnProperty('id')) ? UuidUtils_1.UuidUtils.generateUUID() : req['id'];
            AWSXRay.captureAsyncFunc(this.getSegmentName(), (subsegment) => {
                this.processRequest(req, res)
                    .then((result) => {
                    this.next(req, res, next, result);
                    subsegment.close();
                })
                    .catch((e) => {
                    if (e instanceof ServiceError_1.ServiceError) {
                        res.status(e.status).send(e.message);
                    }
                    else {
                        next(e);
                    }
                    subsegment.close();
                });
            });
        };
    }
}
exports.AbstractController = AbstractController;
//# sourceMappingURL=AbstractController.js.map