import { Context } from '../core/Context';
import { ServiceError } from '../error/ServiceError';
import * as express from 'express';
import { AbstractController } from "./AbstractController";
export declare class Controller extends AbstractController {
    constructor();
    protected checkValidation(req: express.Request): ServiceError;
    protected createContext(): Context;
    protected generateTermGUID(): string;
    resolveServiceError(e: Error): ServiceError;
}
