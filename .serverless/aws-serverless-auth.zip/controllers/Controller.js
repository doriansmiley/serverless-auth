"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Config_1 = require("../core/Config");
const Context_1 = require("../core/Context");
const ServiceError_1 = require("../error/ServiceError");
const UuidUtils_1 = require("../util/UuidUtils");
const AbstractController_1 = require("./AbstractController");
const AbstractController_2 = require("./AbstractController");
class Controller extends AbstractController_1.AbstractController {
    constructor() {
        super();
    }
    checkValidation(req) {
        // first validate the incoming request
        const vResult = this.validate(req);
        if (vResult.error !== null) {
            const error = new ServiceError_1.ServiceError(vResult.error.message, 400);
            this.log(AbstractController_2.LogLevels.ERROR, vResult.error.message, null, req, error);
            return error;
        }
        return null;
    }
    createContext() {
        // create context
        let config = new Config_1.Config();
        return new Context_1.Context(config);
    }
    generateTermGUID() {
        return UuidUtils_1.UuidUtils.generateUUID();
    }
    resolveServiceError(e) {
        let errorCode = 500;
        if (e instanceof RangeError) {
            errorCode = 400;
        }
        else {
            // TODO: add exception handling and set error code appropriately
            errorCode = 500;
        }
        return new ServiceError_1.ServiceError(e.message, errorCode);
    }
}
exports.Controller = Controller;
//# sourceMappingURL=Controller.js.map