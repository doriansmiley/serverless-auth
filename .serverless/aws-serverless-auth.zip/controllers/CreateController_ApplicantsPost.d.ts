import * as express from 'express';
import { Controller } from './Controller';
export declare class CreateController_ApplicantsPost extends Controller {
    constructor();
    protected processRequest(req: express.Request, res: express.Response): Promise<any>;
    protected getSegmentName(): string;
    protected getSchema(): object;
}
