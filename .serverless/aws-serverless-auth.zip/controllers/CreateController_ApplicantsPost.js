"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const AbstractController_1 = require("./AbstractController");
const Controller_1 = require("./Controller");
class CreateController_ApplicantsPost extends Controller_1.Controller {
    constructor() {
        super();
    }
    processRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            // log request received
            this.log(AbstractController_1.LogLevels.INFO, 'Request received', null, req);
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                console.log('CreateController.processRequest: ' + JSON.stringify(req.body));
                // first validate the incoming request
                const error = this.checkValidation(req);
                if (error !== null) {
                    return this.resolvePromise(null, resolve, reject, error, null);
                }
                let json = null;
                try {
                    // create context
                    const context = this.createContext();
                    // TODO: code out your controller logic, be sure to pass context to your business objects.
                    // This makes your code threadsafe when accessing service objects
                    // always access service objects via the context
                    // TODO: set JSON to return
                    json = {
                        tmp: "someValue"
                    };
                }
                catch (e) {
                    const error = this.resolveServiceError(e);
                    this.log(AbstractController_1.LogLevels.ERROR, e.message, null, req, e);
                    return this.resolvePromise(null, resolve, reject, error, null);
                }
                // set response headers, if you do not want cors enabled remove these headers and update the serverless.yml removing cors blocks
                res.set('Access-Control-Allow-Origin', '*');
                res.set('Access-Control-Allow-Credentials', true);
                return this.resolvePromise(json, resolve, reject, null, null);
            }));
        });
    }
    // This function should match route route controller's http verb
    getSegmentName() {
        return 'Create';
    }
    getSchema() {
        // TODO: add you schema validation.
        // This is called by AbstractController.validate and is run against req.body
        // you can also override the AbstractController.getOptions which returns the schema options
        // for more information see joi validation and schema options
        return {
        //id: string().required(),
        //someValue: string().required()
        };
    }
}
exports.CreateController_ApplicantsPost = CreateController_ApplicantsPost;
//# sourceMappingURL=CreateController_ApplicantsPost.js.map