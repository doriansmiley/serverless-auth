import * as express from 'express';
import { Controller } from './Controller';
export declare class CreateController_UsersPost extends Controller {
    constructor();
    protected processRequest(req: express.Request, res: express.Response): Promise<any>;
    protected getSegmentName(): string;
    protected getSchema(): object;
}
