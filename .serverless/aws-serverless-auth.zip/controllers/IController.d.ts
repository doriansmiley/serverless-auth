export interface IController {
    register(): Function;
}
