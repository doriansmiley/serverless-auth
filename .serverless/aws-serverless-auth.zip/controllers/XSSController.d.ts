import { AbstractController } from './AbstractController';
import * as express from 'express';
export declare class XSSController extends AbstractController {
    protected readonly xssConfig: object;
    constructor(xssConfig?: object);
    protected processRequest(req: express.Request, res: express.Response): Promise<any>;
    protected next(req: express.Request, res: express.Response, next: (e?: any) => {}, result: any): void;
    protected getSegmentName(): string;
}
