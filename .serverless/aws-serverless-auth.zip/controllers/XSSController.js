"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const AbstractController_1 = require("./AbstractController");
const AbstractController_2 = require("./AbstractController");
const xss_1 = require("xss");
const ServiceError_1 = require("../error/ServiceError");
class XSSController extends AbstractController_1.AbstractController {
    constructor(xssConfig = {}) {
        super();
        this.xssConfig = {};
        this.xssConfig = xssConfig;
    }
    processRequest(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            // log request recieved
            this.log(AbstractController_2.LogLevels.INFO, 'Request recieved', null, req);
            return new Promise((resolve, reject) => {
                try {
                    const xss = new xss_1.FilterXSS(this.xssConfig);
                    req.body = (req.body) ? JSON.parse(xss.process(JSON.stringify(req.body))) : req.body;
                    return this.resolvePromise(req.body, resolve, reject, null, null);
                }
                catch (e) {
                    const error = new ServiceError_1.ServiceError('Payload is invalid', 400);
                    this.log(AbstractController_2.LogLevels.ERROR, error.message, null, req, e);
                    return this.resolvePromise(null, resolve, reject, error, null);
                }
            });
        });
    }
    // override and call next to proceed with request
    next(req, res, next, result) {
        next();
    }
    getSegmentName() {
        return 'XSSController';
    }
}
exports.XSSController = XSSController;
//# sourceMappingURL=XSSController.js.map