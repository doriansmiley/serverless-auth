import { IConfig } from "./IConfig";
export declare class Config implements IConfig {
    protected _serviceMap: Object;
    baseUrl: string;
    webRoot: string;
    token: string;
    serviceCode: string;
    constructor();
    protected init(): void;
    readonly serviceMap: Object;
    getURLWithParams(serviceName: string, route: string, args?: Array<string>): string;
    getAbsoluteURLWithParams(serviceName: string, route: string, args?: Array<string>): string;
}
