"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const StringUtils_1 = require("../util/StringUtils");
class Config {
    constructor() {
        this._serviceMap = null; // hash to look up routes
        this.webRoot = ''; // path relative to webroot where the application is deployed
        this.token = null; // used for oAuth authentication schemes and similar token based authentication systems
        // used for assigning a concrete service implementation. Must be in the form: /v + version number. for example: /v1
        this.serviceCode = null;
        this.init();
    }
    init() {
        //TODO: add your service maps, this is used for basic microservice discovery and resolution
        this._serviceMap = {
        /* example definition, note the use of route params
        someApi: {
            baseURL: 'https://url',
            port: 'somePort',
            create:  '/noun',
            update: '/noun',
            delete: '/noun/{0}',
            read: '/noun/{0}',
            getInstance: '/noun/instances/{0}/{1}/{2}',
            updateInstance: '/noun/instances',
            evaluateExpression: '/noun/expressions/{0}/{1}'
        }
        */
        };
        this.serviceCode = '/v1';
    }
    get serviceMap() {
        return this._serviceMap;
    }
    getURLWithParams(serviceName, route, args) {
        return this.serviceCode + StringUtils_1.StringUtils.substitute(this.serviceMap[serviceName][route], args);
    }
    getAbsoluteURLWithParams(serviceName, route, args) {
        let baseURL = this.serviceMap[serviceName]['baseURL'];
        if (this.serviceMap[serviceName]['port']) {
            baseURL += ':' + this.serviceMap[serviceName]['port'];
        }
        baseURL += this.serviceCode + StringUtils_1.StringUtils.substitute(this.serviceMap[serviceName][route], args);
        return baseURL;
    }
}
exports.Config = Config;
//# sourceMappingURL=Config.js.map