import { IContext } from "./IContext";
import { IConfig } from "./IConfig";
export declare class Context implements IContext {
    private _config;
    constructor(config: IConfig);
    readonly config: IConfig;
}
