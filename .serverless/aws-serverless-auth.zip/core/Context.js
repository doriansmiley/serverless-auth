"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
* The Context class is used to sandbox individual requests. It can be expanded to include things like
* injectors, a central event bus, command mapping, etc
* */
class Context {
    constructor(config) {
        this._config = config;
    }
    get config() {
        return this._config;
    }
}
exports.Context = Context;
//# sourceMappingURL=Context.js.map