export interface IConfig {
    baseUrl: string;
    webRoot: string;
    token: string;
    serviceCode: string;
    serviceMap: Object;
    getURLWithParams(serviceName: string, route: string, args?: Array<string>): string;
    getAbsoluteURLWithParams(serviceName: string, route: string, args?: Array<string>): string;
}
