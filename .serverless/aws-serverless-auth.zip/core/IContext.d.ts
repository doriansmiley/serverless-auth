import { IConfig } from "./IConfig";
export interface IContext {
    config: IConfig;
}
