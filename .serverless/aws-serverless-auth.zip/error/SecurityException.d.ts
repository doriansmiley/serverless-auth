export declare class SecurityException extends Error {
    static readonly NOT_AUTHORIZED = "Unauthorized to access surveyInstance document.";
    concreteSecurityException: Error;
    constructor(message: string, error?: Error);
}
