"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class SecurityException extends Error {
    constructor(message, error = null) {
        super(message);
        this.concreteSecurityException = null;
        this.concreteSecurityException = error;
    }
}
SecurityException.NOT_AUTHORIZED = 'Unauthorized to access surveyInstance document.';
exports.SecurityException = SecurityException;
//# sourceMappingURL=SecurityException.js.map