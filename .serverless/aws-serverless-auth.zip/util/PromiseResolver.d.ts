export declare class PromiseResolver {
    resolvePromise(result: any, resolve: (value?: any) => void, reject: (value?: any) => void, error?: any, callback?: (v1: any, v2: any) => void): void;
}
