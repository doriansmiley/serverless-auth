"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class PromiseResolver {
    resolvePromise(result, resolve, reject, error = null, callback = null) {
        if (callback !== null) {
            callback(result, error);
        }
        else if (error === null) {
            // the value of result can be null, it is not always defined in the case of async functions
            // therefore if the error is null always call resolve
            resolve(result);
        }
        else {
            reject(error);
        }
    }
}
exports.PromiseResolver = PromiseResolver;
//# sourceMappingURL=PromiseResolver.js.map