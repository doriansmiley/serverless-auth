export declare class StringUtils {
    /**
     * Given a string with placeholders, replace the each placeholder with the equivalent value in given array
     * Replacement is index-based
     * placeholders must be in the following format {<order_in_string>}, ex: {0}, {1}
     *
     * @returns formatted output
     */
    static format(format: string, values: Array<string>): string;
    /**
     * A given a string, escape its characters for use in regex patterns
     * @returns escaped string
     */
    static escapeRegexChars(input: string): string;
    /**
     * Given a string with placeholders, replace the each placeholder with the equivalent value in given array
     * Replacement is not index-based, the index of the item in the array is matched against the corresponding token at that index.
     * For example index 0 will match {0} in the string explicitly, even if the token {0} is the third token in the string
     * placeholders must be in the following format {<order_in_string>}, ex: {1}, {0}, {2}
     *
     * @returns formatted output
     */
    static substitute(str: string, args: Array<string>): string;
    static toUTF8Array(str: any): Uint8Array;
    static fromUTF8Array(uint8array: Uint8Array): string;
}
