export declare class UuidUtils {
    constructor();
    static generateUUID(): string;
    static getRandomInt(min: number, max: number): number;
}
